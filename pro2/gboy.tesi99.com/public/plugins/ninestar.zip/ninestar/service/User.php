<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/5
 * Time: 17:05
 */
namespace app\ninestar\service;
use app\ninestar\model\Init;
class User extends Init{
    public $arr = array('0','一','二','三','四','五','六','七','八','九');
    public function isregister($username) {
        if(!$username) {
            $this->errors = '异常请求';
            return false;
        }
        $re = $this->db->table('star_user')->where("phone = '{$username}'")->value('id');
        if(!$re) {
            $this->errors = '未激活用户';
            return false;
        }
        return true;
    }
    //注册
    public function register($data,$uid) {
        if(!$data || !$data['phone']) {
            $this->errors = '账号不能为空';
            return false;
        }
        if(!is_mobile($data['phone'])) {
            $this->errors = '请输入正确的手机号';
            return false;
        }
        //$data['wechat'] = dowith_sql(strip_tags($data['wechat']));
        //$data['name'] = dowith_sql(strip_tags($data['name']));
        $member_model = model('member/member');
        $user = $member_model->where("username = '{$data['phone']}'")->find();
        if(!$user) {
            $this->errors = '用户不存在';
            return false;
        }
        if($user['pid'] != $uid){
            $this->errors = '非推荐关系不可激活';
            return false;
        }
        $is_regist = $this->db->table('star_user')->where("phone = '{$data['phone']}'")->value('id');
        if($is_regist) {
            $this->errors = '已激活用户';
            return false;
        }
        $member_model->startTrans();
        $reslut =$this->db->table('star_user')->data([
            'id'      => $user['id'],
            'pid'     => $user['pid'],
            'path_id' => $user['path_id'],
            'phone'   => $data['username'],
            'created' => time()
        ])->insert();
        $reslut2 = $this->db->table('star_activate_log')->data([
            'fid'     => $uid,
            'tid'     => $user['id'],
            'phone'   => $user['phone'],
            'created' => time()
        ])->insert();
        if(!$reslut || !$reslut2) {
            $member_model->rollback();
            $this->errors = '激活失败';
            return false;
        }
        $member_model->commit();
        return true;
    }
    //获取最后一位五星用户
    public function getFiveUser($uid) {
        $path_id = $this->db->table('star_user')->where("id = {$uid}")->value('path_id');
        $path_data = explode(',',trim($path_id,','));
        rsort($path_data);
        $userid = '';
        foreach($path_data as $k => $v) {
            if($k == 0) {
                continue;
            }
            $id = $this->db->table('star_user')->where("id = {$v} and level = 5")->value('id');
            if($id) {
                $userid = $id;
                break;
            }
        }
        return $userid;
    }

    //申请升级
    public function apply($uid) {
        $wechat = model('member/memberProfile')->where("uid = {$uid}")->value('wechat');
        if(!$wechat) {
            $this->errors = '请完善微信信息';
            return false;
        }
        $id = $this->db->table('star_apply_log')->where("uid = {$uid} and status = 0")->value('id');
        if($id) {
            $this->errors = '请勿重复申请';
            return false;
        }
        $userid = $this->getFiveUser($uid);
        if(!$userid) {
            $this->errors = '暂无五星用户';
            return false;
        }
        $user = $this->getUser($uid);
        $re = $this->db->table('star_apply_log')->data([
            'uid' => $uid,
            'level' => $user['level'],
            'leaderid' => $userid,
            'status' => 0,
            'created' => time()
        ])->insert();
        if(!$re) {
            $this->errors = '申请失败';
            return false;
        }
        return true;
    }

    //获取升级申请记录
    public function applyList($uid) {
        $list = $this->db->table('star_apply_log')->where("uid = {$uid}")->select();
        if($list) {
            $result = array();
            foreach($list as $k => $v) {
                $leader = $this->getUser($v['leaderid']);
                $result[$v['level']]['list'][] = [
                    'wechat' => $leader['wechat'],
                    'realname' => $leader['realname'],
                    'phone' => $leader['phone'],
                ];
                if(!isset($result[$v['level']]['level'])) {
                    $result[$v['level']]['level'] = $this->arr[$v['level']];
                }
            }
        }
        return $list;
    }
    //审核列表
    public function examineList($uid) {
        $list = $this->db->table('star_apply_log')->where("leaderid = {$uid} and status = 0")->select();
        if($list) {
            $result = array();
            foreach($list as $k => $v) {
                $user = $this->getUser($v['uid']);
                $result[$k]['uid'] = $v['uid'];
                $result[$k]['realname'] = $user['realname'];
                $result[$k]['phone'] = $user['phone'];
                $result[$k]['wecaht'] = $user['wecaht'];
                $result[$k]['created'] = date('Y-m-d H:i:s', $v['created']);
            }
        }
        return $result;
    }

    //审核
    public function examine($uid, $leaderid) {
        $log_re = $level_re = false;
        $this->db->transaction();
        $log_re = $this->db->table('star_apply_log')->where("uid = {$uid} and leaderid = {$leaderid} and status = 0")->data(['status' => 1,'utime'=>time()])->update();
        if($log_re !== false) {
            $level_re = $this->db->table('star_use')->where("uid = {$uid}")->data(['level' => 'level' + 1])->update();
        }
        if(!$log_re || $level_re) {
            $this->db->rollback();
            $this->errors = '审核失败';
            return false;
        }
        $this->db->commit();
        return true;
    }

    //获取激活记录
    public function getRegisterList($uid) {
        $list = $this->db->table('star_activate_log')->where("fid = {$uid}")->select();
        if($list) {
            foreach($list as $k => $v) {
                $list[$k]['created'] = date('Y-m-d H:i:s', $v['created']);
            }
        }
        return $list;
    }


    //获取用户数据
    public function getUser($uid) {
        $user = $this->db->table('star_user')->where("id = {$uid}")->find();
        if($user) {
            $data = model('member/member')->where("id = {$uid}")->find();
            $wechat = model('member/memberProfile')->where("uid = {$uid}")->value('wechat');
            $user['face'] = $data['face'] ? $data['face'] : "__ROOT__/template/wap/ninestar/static/img/user.jpg";
            $user['realname'] = $data['realname'] ? $data['realname'] : $data['username'];
            $user['wechat'] = $wechat;
        }
        return $user;
    }

    public function teamList($uid) {
        $list = $this->db->table('star_user')->where("pid = {$uid}")->select();
        if($list) {
            $result = array();
            foreach($list as $k => $v) {
                if($v['level'] == 0) {
                    $result[$k]['level'] = '普通会员';
                }else{
                    $result[$k]['level'] = $this->arr[$v['level']].'级会员';
                }
                $user = $this->getUser($v['id']);
                $result[$k]['realname'] = $user['realname'];
                $result[$k]['wecaht'] = $user['wechat'];
                $result[$k]['created'] = date('Y-m-d H:i:s', $v['created']);
            }
        }
        return $result;
    }

    public function getCount($uid) {
        return $this->db->table('star_user')->where("pid = {$uid} and level >= 1")->count();
    }
}